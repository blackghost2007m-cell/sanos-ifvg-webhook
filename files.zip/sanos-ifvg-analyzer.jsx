import { useState, useRef, useEffect } from "react";

const SYSTEM_PROMPT = `You are an expert ICT/SMC trader and analyst specializing in the Sanos Simplified IFVG Setup strategy. 

STRATEGY RULES (analyze STRICTLY against these):

1. LIQUIDITY SWEEP (REQUIRED)
- Must identify a swing high or swing low on the 5-MINUTE timeframe
- That swing must have PREVIOUSLY bounced or rejected from a Fair Value Gap (FVG)
- Lower timeframes than 5m = lower probability, should be flagged
- PASS / FAIL / PARTIAL

2. DELIVERY (REQUIRED)
- Entry timeframe must pair with a MATCHING delivery timeframe (e.g., 30s inverse → 30s FVG delivery)
- If no matching TF, look at higher/lower TF for delivery
- If NO delivery from ANY timeframe → DO NOT TAKE THE TRADE
- PASS / FAIL / PARTIAL

3. FVG SIZE (REQUIRED)
- Minimum 9 POINTS gap size
- Use TradingView measure tool (SHIFT+click) to verify
- Below 9 points = skip the setup
- PASS / FAIL / UNKNOWN (if size not provided)

4. TARGETS (REQUIRED)
- Must have CLEAR, OBVIOUS targets: trendline liquidity, equal highs/lows, intermediate highs/lows
- Must have a safe break-even spot
- No clear targets = DO NOT TAKE THE TRADE
- PASS / FAIL / PARTIAL

5. BONUS FACTORS (optional but increase confidence):
- SMT (Smart Money Tool / divergence)
- Price in Premium or Discount zone of a Higher Time Frame range
- Both together = HIGHEST CONFIDENCE setup

RESPONSE FORMAT (always respond in JSON only, no markdown):
{
  "verdict": "TAKE TRADE" | "DO NOT TAKE" | "WAIT FOR CONFIRMATION",
  "confidence": 0-100,
  "criteria": {
    "liquidity_sweep": { "status": "PASS" | "FAIL" | "PARTIAL" | "UNKNOWN", "note": "brief explanation" },
    "delivery": { "status": "PASS" | "FAIL" | "PARTIAL" | "UNKNOWN", "note": "brief explanation" },
    "fvg_size": { "status": "PASS" | "FAIL" | "PARTIAL" | "UNKNOWN", "note": "brief explanation" },
    "targets": { "status": "PASS" | "FAIL" | "PARTIAL" | "UNKNOWN", "note": "brief explanation" },
    "bonus": { "status": "YES" | "NO" | "PARTIAL", "note": "brief explanation" }
  },
  "summary": "2-3 sentence overall analysis",
  "action": "Specific actionable advice for the trader"
}`;

const statusColors = {
  PASS: { bg: "#0d2818", border: "#00ff88", text: "#00ff88" },
  FAIL: { bg: "#2a0a0a", border: "#ff3b3b", text: "#ff3b3b" },
  PARTIAL: { bg: "#2a1f00", border: "#ffaa00", text: "#ffaa00" },
  UNKNOWN: { bg: "#1a1a2e", border: "#666", text: "#aaa" },
  YES: { bg: "#0d1f3c", border: "#4499ff", text: "#4499ff" },
  NO: { bg: "#1a1a1a", border: "#444", text: "#888" },
};

const verdictStyles = {
  "TAKE TRADE": { color: "#00ff88", shadow: "0 0 30px #00ff8866", label: "✅ TAKE TRADE" },
  "DO NOT TAKE": { color: "#ff3b3b", shadow: "0 0 30px #ff3b3b66", label: "🚫 DO NOT TAKE" },
  "WAIT FOR CONFIRMATION": { color: "#ffaa00", shadow: "0 0 30px #ffaa0066", label: "⏳ WAIT FOR CONFIRMATION" },
};

const criteriaLabels = {
  liquidity_sweep: { icon: "🧹", label: "Liquidity Sweep" },
  delivery: { icon: "🚛", label: "Delivery" },
  fvg_size: { icon: "📏", label: "FVG Size" },
  targets: { icon: "🎯", label: "Targets" },
  bonus: { icon: "⭐", label: "Bonus (SMT / HTF P&D)" },
};

function ConfidenceMeter({ value }) {
  const color = value >= 75 ? "#00ff88" : value >= 50 ? "#ffaa00" : "#ff3b3b";
  return (
    <div style={{ marginBottom: 20 }}>
      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6, fontSize: 12, color: "#888", letterSpacing: 2, textTransform: "uppercase" }}>
        <span>Confidence</span>
        <span style={{ color, fontWeight: 700, fontSize: 14 }}>{value}%</span>
      </div>
      <div style={{ height: 6, background: "#1a1a1a", borderRadius: 3, overflow: "hidden" }}>
        <div style={{
          height: "100%",
          width: `${value}%`,
          background: `linear-gradient(90deg, ${color}88, ${color})`,
          borderRadius: 3,
          transition: "width 1s ease",
          boxShadow: `0 0 8px ${color}`
        }} />
      </div>
    </div>
  );
}

export default function SanosAnalyzer() {
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);
  const [messages, setMessages] = useState([]);
  const textareaRef = useRef(null);

  const examples = [
    "5m swing low swept, 30s IFVG formed, size ~12 pts, target equal highs at 3320",
    "1m sweep, delivery from 1m FVG, gap is 6 points, no clear targets",
    "5m swing high swept, 15m delivery, gap 14pts, SMT on DXY, targets at prev high 3340, in HTF discount zone",
  ];

  const analyze = async (userMessage) => {
    if (!userMessage.trim()) return;
    setLoading(true);
    setError(null);
    setResult(null);

    const newMessages = [...messages, { role: "user", content: userMessage }];
    setMessages(newMessages);

    try {
      const response = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 1000,
          system: SYSTEM_PROMPT,
          messages: newMessages,
        }),
      });

      const data = await response.json();
      const raw = data.content?.map(b => b.text || "").join("") || "";
      const cleaned = raw.replace(/```json|```/g, "").trim();
      const parsed = JSON.parse(cleaned);
      setResult(parsed);
      setMessages([...newMessages, { role: "assistant", content: raw }]);
    } catch (e) {
      setError("Analysis failed. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = () => {
    if (input.trim() && !loading) {
      analyze(input.trim());
      setInput("");
    }
  };

  const handleKey = (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  return (
    <div style={{
      minHeight: "100vh",
      background: "#0a0a0a",
      fontFamily: "'Courier New', monospace",
      color: "#e0e0e0",
      padding: "24px 16px",
    }}>
      {/* Header */}
      <div style={{ textAlign: "center", marginBottom: 32 }}>
        <div style={{
          display: "inline-block",
          background: "linear-gradient(135deg, #ff3b3b, #ff8800)",
          WebkitBackgroundClip: "text",
          WebkitTextFillColor: "transparent",
          fontSize: 28,
          fontWeight: 900,
          letterSpacing: 3,
          marginBottom: 4,
        }}>
          SANOS IFVG ANALYZER
        </div>
        <div style={{ fontSize: 11, color: "#555", letterSpacing: 4, textTransform: "uppercase" }}>
          Simplified Setup · 4-Criteria Filter
        </div>
        <div style={{
          display: "flex", justifyContent: "center", gap: 24, marginTop: 16,
          fontSize: 11, color: "#444"
        }}>
          {["🧹 Sweep", "🚛 Delivery", "📏 FVG ≥9pts", "🎯 Targets"].map(t => (
            <span key={t} style={{ letterSpacing: 1 }}>{t}</span>
          ))}
        </div>
      </div>

      {/* Input Area */}
      <div style={{
        maxWidth: 680,
        margin: "0 auto 24px",
        background: "#111",
        border: "1px solid #222",
        borderRadius: 8,
        overflow: "hidden",
      }}>
        <div style={{ padding: "12px 16px", borderBottom: "1px solid #1a1a1a", fontSize: 11, color: "#555", letterSpacing: 2 }}>
          DESCRIBE YOUR SETUP
        </div>
        <textarea
          ref={textareaRef}
          value={input}
          onChange={e => setInput(e.target.value)}
          onKeyDown={handleKey}
          placeholder="e.g. 5m swing low swept, 30s IFVG delivery, gap 12pts, target equal highs 3320, SMT on DXY..."
          style={{
            width: "100%",
            minHeight: 100,
            background: "transparent",
            border: "none",
            color: "#e0e0e0",
            fontSize: 14,
            padding: "16px",
            resize: "none",
            outline: "none",
            fontFamily: "inherit",
            boxSizing: "border-box",
          }}
        />
        <div style={{ padding: "8px 16px", display: "flex", justifyContent: "space-between", alignItems: "center", borderTop: "1px solid #1a1a1a" }}>
          <span style={{ fontSize: 11, color: "#333" }}>Enter to analyze · Shift+Enter for new line</span>
          <button
            onClick={handleSubmit}
            disabled={loading || !input.trim()}
            style={{
              background: loading ? "#1a1a1a" : "linear-gradient(135deg, #ff3b3b, #ff8800)",
              color: loading ? "#555" : "#fff",
              border: "none",
              borderRadius: 4,
              padding: "8px 20px",
              cursor: loading ? "not-allowed" : "pointer",
              fontSize: 12,
              fontWeight: 700,
              letterSpacing: 2,
              fontFamily: "inherit",
            }}
          >
            {loading ? "ANALYZING..." : "ANALYZE →"}
          </button>
        </div>
      </div>

      {/* Quick Examples */}
      {!result && !loading && (
        <div style={{ maxWidth: 680, margin: "0 auto 32px" }}>
          <div style={{ fontSize: 11, color: "#333", letterSpacing: 2, marginBottom: 10 }}>QUICK EXAMPLES:</div>
          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            {examples.map((ex, i) => (
              <button key={i} onClick={() => setInput(ex)} style={{
                background: "#0f0f0f",
                border: "1px solid #1e1e1e",
                borderRadius: 4,
                color: "#555",
                padding: "8px 12px",
                textAlign: "left",
                cursor: "pointer",
                fontSize: 12,
                fontFamily: "inherit",
                transition: "border-color 0.2s",
              }}
                onMouseEnter={e => e.target.style.borderColor = "#333"}
                onMouseLeave={e => e.target.style.borderColor = "#1e1e1e"}
              >
                {ex}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Loading */}
      {loading && (
        <div style={{ maxWidth: 680, margin: "0 auto", textAlign: "center", padding: 40 }}>
          <div style={{ fontSize: 12, color: "#555", letterSpacing: 4, marginBottom: 16 }}>RUNNING ANALYSIS</div>
          <div style={{ display: "flex", justifyContent: "center", gap: 6 }}>
            {[0, 1, 2, 3].map(i => (
              <div key={i} style={{
                width: 8, height: 8, borderRadius: "50%",
                background: "#ff6600",
                animation: `pulse 1s ${i * 0.2}s infinite`,
              }} />
            ))}
          </div>
          <style>{`@keyframes pulse { 0%,100%{opacity:0.2} 50%{opacity:1} }`}</style>
        </div>
      )}

      {/* Error */}
      {error && (
        <div style={{ maxWidth: 680, margin: "0 auto", background: "#2a0a0a", border: "1px solid #ff3b3b33", borderRadius: 8, padding: 16, color: "#ff3b3b", fontSize: 13 }}>
          {error}
        </div>
      )}

      {/* Result */}
      {result && !loading && (
        <div style={{ maxWidth: 680, margin: "0 auto" }}>
          {/* Verdict Banner */}
          <div style={{
            textAlign: "center",
            padding: "28px 20px",
            marginBottom: 20,
            background: "#111",
            border: `1px solid ${verdictStyles[result.verdict]?.color || "#444"}33`,
            borderRadius: 8,
            boxShadow: verdictStyles[result.verdict]?.shadow || "none",
          }}>
            <div style={{
              fontSize: 28, fontWeight: 900, letterSpacing: 4,
              color: verdictStyles[result.verdict]?.color || "#fff",
              marginBottom: 12,
            }}>
              {verdictStyles[result.verdict]?.label || result.verdict}
            </div>
            <ConfidenceMeter value={result.confidence} />
            <p style={{ fontSize: 13, color: "#aaa", margin: 0, lineHeight: 1.7 }}>
              {result.summary}
            </p>
          </div>

          {/* Criteria Grid */}
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 16 }}>
            {Object.entries(result.criteria || {}).map(([key, val]) => {
              const meta = criteriaLabels[key];
              const style = statusColors[val.status] || statusColors.UNKNOWN;
              return (
                <div key={key} style={{
                  background: style.bg,
                  border: `1px solid ${style.border}44`,
                  borderRadius: 6,
                  padding: "12px 14px",
                  gridColumn: key === "bonus" ? "1 / -1" : "auto",
                }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 6 }}>
                    <span style={{ fontSize: 12, color: "#aaa" }}>
                      {meta?.icon} {meta?.label}
                    </span>
                    <span style={{
                      fontSize: 11, fontWeight: 700, letterSpacing: 2,
                      color: style.text, border: `1px solid ${style.border}66`,
                      padding: "2px 8px", borderRadius: 3,
                    }}>
                      {val.status}
                    </span>
                  </div>
                  <p style={{ margin: 0, fontSize: 12, color: "#777", lineHeight: 1.5 }}>
                    {val.note}
                  </p>
                </div>
              );
            })}
          </div>

          {/* Action Box */}
          <div style={{
            background: "#0f1a0f",
            border: "1px solid #00ff8822",
            borderRadius: 8,
            padding: "16px",
            marginBottom: 20,
          }}>
            <div style={{ fontSize: 11, color: "#00ff8866", letterSpacing: 3, marginBottom: 8 }}>ACTION</div>
            <p style={{ margin: 0, fontSize: 13, color: "#ccc", lineHeight: 1.7 }}>{result.action}</p>
          </div>

          {/* New Analysis Button */}
          <div style={{ textAlign: "center" }}>
            <button onClick={() => { setResult(null); setInput(""); setMessages([]); }} style={{
              background: "transparent",
              border: "1px solid #333",
              color: "#555",
              padding: "10px 24px",
              borderRadius: 4,
              cursor: "pointer",
              fontSize: 12,
              fontFamily: "inherit",
              letterSpacing: 2,
            }}>
              NEW ANALYSIS
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
