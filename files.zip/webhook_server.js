// ══════════════════════════════════════════════════════
//  SANOS IFVG WEBHOOK SERVER
//  TradingView → This Server → Claude API → Telegram
// ══════════════════════════════════════════════════════
//
//  Setup:
//  1. npm install express node-fetch
//  2. Set environment variables (see .env below)
//  3. node server.js
//  4. Deploy to Render.com (free) or Railway
//  5. Paste your URL in TradingView alert webhook field
//
//  .env file:
//  ANTHROPIC_API_KEY=sk-ant-...
//  TELEGRAM_BOT_TOKEN=...
//  TELEGRAM_CHAT_ID=...
//  PORT=3000

import express from "express";
import fetch from "node-fetch";

const app = express();
app.use(express.json());

const ANTHROPIC_KEY   = process.env.ANTHROPIC_API_KEY;
const TG_TOKEN        = process.env.TELEGRAM_BOT_TOKEN;
const TG_CHAT_ID      = process.env.TELEGRAM_CHAT_ID;
const PORT            = process.env.PORT || 3000;

// ── Sanos Strategy Prompt ────────────────────────────
const SYSTEM_PROMPT = `You are a professional ICT/SMC trader. Analyze the incoming IFVG setup strictly using the Sanos Simplified IFVG rules:

REQUIRED criteria (all must pass for TAKE TRADE):
1. LIQUIDITY SWEEP — swing high/low on 5m TF that previously rejected from FVG
2. DELIVERY — entry TF must have matching delivery TF (e.g. 30s inverse → 30s FVG)
3. FVG SIZE — minimum 9 points gap
4. TARGETS — clear trendline liquidity / equal highs-lows / ITH-ITL + safe BE spot

BONUS (not required, boosts confidence):
- SMT divergence
- Price in HTF Premium (bearish) or Discount (bullish)

Respond ONLY in JSON, no markdown:
{
  "verdict": "TAKE TRADE" | "DO NOT TAKE" | "WAIT FOR CONFIRMATION",
  "confidence": 0-100,
  "entry": suggested entry price or "wait",
  "sl": suggested stop loss price or "undefined",
  "tp1": first target or "undefined",
  "tp2": second target or "undefined",
  "criteria": {
    "sweep":    { "status": "PASS|FAIL|PARTIAL|UNKNOWN", "note": "..." },
    "delivery": { "status": "PASS|FAIL|PARTIAL|UNKNOWN", "note": "..." },
    "fvg_size": { "status": "PASS|FAIL|PARTIAL|UNKNOWN", "note": "..." },
    "targets":  { "status": "PASS|FAIL|PARTIAL|UNKNOWN", "note": "..." },
    "bonus":    { "status": "YES|NO|PARTIAL",             "note": "..." }
  },
  "summary": "2-3 sentence analysis",
  "action": "specific actionable advice"
}`;

// ── Claude Analysis ──────────────────────────────────
async function analyzeWithClaude(setupData) {
  const userMessage = `
New IFVG Alert from TradingView:
- Symbol: ${setupData.symbol}
- Timeframe: ${setupData.tf}
- Direction: ${setupData.direction}
- Current Price: ${setupData.price}
- FVG Top: ${setupData.fvg_top}
- FVG Bottom: ${setupData.fvg_bot}
- FVG Size: ${setupData.fvg_size} points
- Swept Level: ${setupData.swept_level}
- Time: ${setupData.time}

Based on visible data, analyze this setup against Sanos IFVG criteria. 
Note: Delivery and Targets cannot be fully confirmed from this data alone — flag them as PARTIAL/UNKNOWN if insufficient info.
`;

  const response = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": ANTHROPIC_KEY,
      "anthropic-version": "2023-06-01",
    },
    body: JSON.stringify({
      model: "claude-sonnet-4-20250514",
      max_tokens: 1000,
      system: SYSTEM_PROMPT,
      messages: [{ role: "user", content: userMessage }],
    }),
  });

  const data = await response.json();
  const raw = data.content?.map(b => b.text || "").join("") || "{}";
  return JSON.parse(raw.replace(/```json|```/g, "").trim());
}

// ── Telegram Notification ────────────────────────────
async function sendTelegram(analysis, setup) {
  if (!TG_TOKEN || !TG_CHAT_ID) return;

  const verdictEmoji = {
    "TAKE TRADE": "✅",
    "DO NOT TAKE": "🚫",
    "WAIT FOR CONFIRMATION": "⏳",
  }[analysis.verdict] || "❓";

  const statusEmoji = { PASS: "✅", FAIL: "❌", PARTIAL: "⚠️", UNKNOWN: "❓", YES: "✅", NO: "❌" };

  const msg = `
${verdictEmoji} *${analysis.verdict}* — ${setup.symbol} ${setup.tf}
📊 Direction: ${setup.direction}
💰 Price: ${setup.price}
📈 Confidence: ${analysis.confidence}%

*Criteria:*
${statusEmoji[analysis.criteria.sweep?.status]} Sweep: ${analysis.criteria.sweep?.note}
${statusEmoji[analysis.criteria.delivery?.status]} Delivery: ${analysis.criteria.delivery?.note}
${statusEmoji[analysis.criteria.fvg_size?.status]} FVG Size: ${setup.fvg_size}pts — ${analysis.criteria.fvg_size?.note}
${statusEmoji[analysis.criteria.targets?.status]} Targets: ${analysis.criteria.targets?.note}
${statusEmoji[analysis.criteria.bonus?.status]} Bonus: ${analysis.criteria.bonus?.note}

📝 ${analysis.summary}

🎯 *Action:* ${analysis.action}

${analysis.entry !== "wait" ? `Entry: ${analysis.entry}\nSL: ${analysis.sl}\nTP1: ${analysis.tp1}\nTP2: ${analysis.tp2}` : "⏳ Wait for better setup"}
`.trim();

  await fetch(`https://api.telegram.org/bot${TG_TOKEN}/sendMessage`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      chat_id: TG_CHAT_ID,
      text: msg,
      parse_mode: "Markdown",
    }),
  });
}

// ── Webhook Endpoint ─────────────────────────────────
app.post("/webhook", async (req, res) => {
  console.log("📩 Alert received:", JSON.stringify(req.body, null, 2));

  try {
    const setup = req.body;

    // Validate required fields
    if (!setup.symbol || !setup.direction) {
      return res.status(400).json({ error: "Invalid payload" });
    }

    // Analyze with Claude
    console.log("🤖 Sending to Claude...");
    const analysis = await analyzeWithClaude(setup);
    console.log("✅ Analysis:", analysis.verdict, `(${analysis.confidence}%)`);

    // Send to Telegram
    await sendTelegram(analysis, setup);

    res.json({ ok: true, verdict: analysis.verdict, confidence: analysis.confidence });

  } catch (err) {
    console.error("❌ Error:", err.message);
    res.status(500).json({ error: err.message });
  }
});

// ── Health Check ─────────────────────────────────────
app.get("/", (req, res) => {
  res.json({ status: "Sanos IFVG Webhook Server running ✅", port: PORT });
});

app.listen(PORT, () => {
  console.log(`🚀 Server running on port ${PORT}`);
  console.log(`📡 Webhook URL: http://localhost:${PORT}/webhook`);
});
